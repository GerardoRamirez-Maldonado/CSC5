/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 4, 2022, 2:36 PM
 * Purpose:  Trig HW Problem
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float PI = 3.14159265359;

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float angdeg, //angle in degrees
          angrad, //angle in radians
          sindeg, //sine of the angle
          cosdeg, //cos of the angle
          tandeg; //tan of the angle
    
    //Initialize or input i.e. set variable values
    cout<<"Calculate trig functions"<<endl;
    cout<<"Input the angle in degrees.\n";
    cin>>angdeg;
    
    //Map inputs -> outputs
    angrad= angdeg * PI/180; 
    sindeg= sin(angrad);
    cosdeg= cos(angrad);
    tandeg= tan(angrad);
    
    //Display the outputs
    cout<<fixed<<setprecision(0)<<"sin("<<angdeg<<") = "<<setprecision(4)<<sindeg<<endl;
    cout<<setprecision(0)<<"cos("<<angdeg<<") = "<<setprecision(4)<<cosdeg<<endl;
    cout<<setprecision(0)<<"tan("<<angdeg<<") = "<<setprecision(4)<<tandeg;

    //Exit stage right or left!
    return 0;
}