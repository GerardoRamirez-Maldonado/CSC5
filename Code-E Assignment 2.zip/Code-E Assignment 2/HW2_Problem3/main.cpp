/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldondo
 * Created on July 4th, 2022, 11:36 AM
 * Purpose:  Assignment 2 Problem 3
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float PERCENT=1e2f;//100 converion to percent

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float hmvl,   //home value
          totcvg, //total coverage needed
          cvgpct; //coverage minimum
    
    //Initialize or input i.e. set variable values
   cvgpct = 80/PERCENT;
    
    //Map inputs -> outputs
    cout<<"Insurance Calculator"<<endl;
    cout<<"How much is your house worth?\n";
    cin>>hmvl;
    totcvg=hmvl*cvgpct;
    
    
    //Display the outputs
    cout<<"You need $"<<totcvg<<" of insurance.";
    
    //Exit stage right or left!
    return 0;
}
