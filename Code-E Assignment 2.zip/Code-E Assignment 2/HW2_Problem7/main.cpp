/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 4, 2022, 1:45 PM
 * Purpose:  Diet Coke HW Problem
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    const float artswt=0.001f;//artificial sweetner
    float spmass,//soda pop 350 mass
          toxlbh,//toxicity at human weight
          toxlbm,//toxicity at mouse weight
          spartst;//soda pop percent artifical sweetner
    int dlbs, //dieters desired weight
        maxsp;//max soda pop 
    
    
    //Initialize or input i.e. set variable values
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    cout<<"Input the desired dieters weight in lbs.\n";
    cin>>dlbs;
    spmass=350;
    spartst= artswt*spmass;
    toxlbh=45359.2/100;
    toxlbm= 5.0/35;
    
    
    
    //Map inputs -> outputs
    maxsp=(dlbs*toxlbh)*toxlbm/spartst;
    
    //Display the outputs
    cout<<"The maximum number of soda pop cans"<<endl;
    cout<<"which can be consumed is "<<maxsp<<" cans";
    //Exit stage right or left!
    return 0;
}

