/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 4, 2022, 5:36 PM
 * Purpose:  HW Assignment 2 Sums Problem
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int
        posS=0, //positive Sum
        negS=0, //negative Sum
        totS=0, //total Sum 
        in1, in2, in3, in4, in5, in6, in7, in8, in9, in10;//10 inputs
        
    //Initialize or input i.e. set variable values
    cout<<"Input 10 numbers, any order, positive or negative\n";
    cin>>in1>>in2>>in3>>in4>>in5>>in6>>in7>>in8>>in9>>in10;
    
    //Map inputs -> outputs
    in1>=0?posS+=in1:negS+=in1;
    in2>=0?posS+=in2:negS+=in2;
    in3>=0?posS+=in3:negS+=in3;
    in4>=0?posS+=in4:negS+=in4;
    in5>=0?posS+=in5:negS+=in5;
    in6>=0?posS+=in6:negS+=in6;
    in7>=0?posS+=in7:negS+=in7;
    in8>=0?posS+=in8:negS+=in8;
    in9>=0?posS+=in9:negS+=in9;
    in10>=0?posS+=in10:negS+=in10;
    totS=posS+negS;
    
    //Display the outputs
    cout<<fixed;
    cout<<"Negative sum ="<<setw(4)<<negS<<endl;
    cout<<"Positive sum ="<<setw(4)<<posS<<endl;
    cout<<"Total sum    ="<<setw(4)<<totS;
    
    //Exit stage right or left!
    return 0;
}
