/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 4th, 2022, 12:00 PM
 * Purpose:  Assignment 2 Problem 2
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int       cktot,   //40 total cookies per bag
              srvg,    //10 servings in bag
              srvgcal; //300 calories per serving
    float     cketn,   //cookies eaten
              srvgetn, //amount of servings eaten
              totcal,  //total calories consumed
              cksrvg;  //4 cookies per serving
              
              
    //Initialize or input i.e. set variable values
    cktot=   40;
    srvg=    10;
    srvgcal= 300;
    cksrvg=  4;
    
    //Map inputs -> outputs
    cout<<"Calorie Counter"<<endl;
    cout<<"How many cookies did you eat?\n";
    cin>>cketn;
    srvgetn=cketn/cksrvg;
    totcal=srvgetn*srvgcal;
    
    //Display the outputs
    cout<<"You consumed "<<totcal<<" calories.";
    
    //Exit stage right or left!
    return 0;
}

