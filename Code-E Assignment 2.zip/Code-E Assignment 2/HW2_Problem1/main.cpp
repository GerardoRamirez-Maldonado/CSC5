/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 3, 2022, 11:15am
 * Purpose:  Average HW Problem
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float in1, //input 1
          in2, //input 2
          in3, //input 3
          in4, //input 4
          in5, //input 5
          avg, //average of inputs
          tot; //total of inputs
    
    //Initialize or input i.e. set variable values
    cout<<"Input 5 numbers to average."<<endl;
    cin>>in1>>in2>>in3>>in4>>in5;
    
    //Map inputs -> outputs
    tot= in1+in2+in3+in4+in5;
    avg= tot/5;
    
    //Display the outputs
    cout<<fixed<<setprecision(1);
    cout<<"The average = "<<avg;

    //Exit stage right or left!
    return 0;
}

