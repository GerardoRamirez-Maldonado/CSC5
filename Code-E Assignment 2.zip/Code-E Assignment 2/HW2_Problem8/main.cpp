/* 
 * File:   main.cpp
 * Author: Gerardo Ramirez-Maldonado
 * Created on July 4, 2022, 3:35 PM
 * Purpose:  Assignment 2 Pay Problem
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    const int months=12; //months in a year
    float payinc,        //7.6% pay increase
          preann,        //previous annual salary
          newann,        //new annual salary
          nmonsal,       //new monthly salary
          retpay;        //retroactive pay
    
    //Initialize or input i.e. set variable values
    cout<<"Input previous annual salary."<<endl;
    cin>>preann;
    payinc=.076;         //7.6%
    
    //Map inputs -> outputs
    newann=preann*payinc+preann;
    retpay=6*(newann-preann)/12;
    nmonsal=newann/months;
    
    //Display the outputs
    cout<<fixed<<setprecision(2);
    cout<<"Retroactive pay    = $"<<setw(7)<<retpay<<endl;
    cout<<"New annual salary  = $"<<setw(3)<<newann<<endl;
    cout<<"New monthly salary = $"<<setw(7)<<nmonsal;

    //Exit stage right or left!
    return 0;
}

